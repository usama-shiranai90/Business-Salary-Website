<?php
class Database
{
/*    private static $dbName = 'caltax' ;
    private static $dbHost = 'localhost' ;
    private static $dbUsername = 'root';
    private static $dbUserPassword = 'osama123';
    private static $cont  = null;*/

    private static $dbName = 'vutdgcLlF5' ;
    private static $dbHost = 'remotemysql.com' ;
    private static $dbUsername = 'vutdgcLlF5';
    private static $dbUserPassword = 'Va2KcNwwgT';
    private static $cont  = null;

    private function __construct() {
        die('Init function is not allowed');
    }

    public static function getConnection()
    {
        // One connection through whole application
        if (null == self::$cont){

            try{
                self::$cont = mysqli_connect(self::$dbHost,self::$dbUsername,self::$dbUserPassword,self::$dbName);
//                self::$cont =  new PDO( "mysql:host=".self::$dbHost.";"."dbname=".self::$dbName, self::$dbUsername, self::$dbUserPassword);
//                self::$cont->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
//			   echo "Connected successfully";
            }
            catch(PDOException $e){
                die("Oops");
                echo "Connection failed: " . $e->getMessage();
            }

        }
        return self::$cont;
    }

    public static function disconnect()
    {
        self::$cont = null;
    }
}
?>

<!-- Saim Hosting DB -->

<!--

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'fudcams_fudscams' );

/** MySQL database username */
define( 'DB_USER', 'fudcams' );

/** MySQL database password */
define( 'DB_PASSWORD', 'A;}aiY}}^%lT' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );



-->



<!--
private static $dbName = 'fudcams_billing' ;
private static $dbHost = 'mysql2.blazingfast.io' ;
private static $dbUsername = 'fudcams_billing';
private static $dbUserPassword = 'Yc9V=l$su9)2';
private static $cont  = null;


-->
