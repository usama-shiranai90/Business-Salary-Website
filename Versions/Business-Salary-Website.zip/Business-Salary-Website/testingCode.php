<?php

echo (string)number_format("1000000",2)

?>

